INSERT INTO `Duenho` (`dni`,`nombre`,`apellido`, `direccion`) VALUES
(35202546, "Alberto", "Gonzalez", "Alvear 530"),
(25486789, "Gonzalo", "Alcaraz", "Rio negro 50"),
(32879451, "Federico", "Rodriguez", "Paso 75"),
(34555843, "Gabriel", "Fernandez", "Pastor 652"),
(24789563, "Alejandro", "Alvarez", "Estados Unidos 60");

INSERT INTO `Inversor` (`dni`,`nombre`,`apellido`,`direccion`,`mail`,`estado_civil`) VALUES
(3000050, "Rodrigo", "Lopez", "La Plata 1050", "RLopez@gmail.com","Casado"),
(3987415, "Fabricio", "Morandi", "Buenos Aires 2013", "MorandiFab@gmail.com","Soltero"),
(3745684, "Julieta", "Sena", "Rio Grande 154", "JuliSena@gmail.com","Casado"),
(3412586, "Dante", "Cuffia", "Ushuaia 211", "CuffiaD@gmail.com","Soltero"),
(3645874, "Leandro", "Alvarez", "Maria Magdalena 124", "LAlvarez@gmail.com","Soltero");

INSERT INTO telefono_inversor (dni,telefono) VALUES 
(3000050, "2964-451235"),
(3987415, "358-4554681"),
(3745684, "358-6565987"),
(3412586, "358-4587985"),
(3645874, "358-456789"),
(3645874, "358-454755"),
(3987415, "358-6542314"),
(3412586, "358-8978941"),
(3645874, "358-1268946");

INSERT INTO Campanha (anho, precio_bulbo, precio_pistillo) VALUES
(2020, 20.45, 45),
(2021, 21.75, 43.25),
(2022, 19.50, 40),
(2023, 25, 48),
(2024, 23, 42.50);

INSERT INTO Campo (id_campo,nombre,ubicacion,cantidad_bateas,dni ) VALUES 
(1,"Trabod","Santa Rosa",3300,35202546),
(2,"Capataz","Cordoba",1500,25486789),
(3,"Maria Emilia","Mendoza",3000,32879451),
(4,"La Rosa","Cordoba",2560,34555843),
(5,"Mortero","Rio Cuarto",1400,24789563);

insert into Invertir values
(1, 3000050),
(2, 3000050),
(1, 3987415),
(3, 3745684),
(4, 3745684),
(1, 3745684),
(2, 3645874);

INSERT INTO `Realiza` (`anho`,`id_campo`,`dni`,`dinero`,`cantidad_bulbos_generados`,`cantidad_pistillos`,`batea`) VALUES 
(2020,1,3000050,150000.00,1500,4500,40),
(2021,2,3987415,400000.00,2000,6000,154),
(2022,3,3745684,50000.00,400,1200,12),
(2023,4,3412586,120000.00,1000,3000,25),
(2024,5,3645874,200000.00,4500,13500,34);