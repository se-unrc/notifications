create schema Azafran;

create table Duenho (dni Integer not null,
nombre varchar(50) not null, 
apellido varchar(50) not null,
direccion varchar(50),
constraint pk_duenho primary key (dni),
constraint restriccion_dni check (dni > 0));

create table telefono_inversor(dni integer not null,
telefono varchar(30) not null,
constraint pk_telefono_inversor primary key (dni, telefono),
constraint restriccion_dni check (dni > 0),
constraint restriccion_telefono check (telefono > 0));

create table Inversor (dni Integer not null,
nombre varchar(50) not null,
apellido varchar (50),
direccion varchar(50),
mail varchar (50),
estado_civil varchar (50),
constraint pk_innversor primary key(dni),
constraint restriccion_dni check (dni > 0),
constraint restriccion_estado_civil check (estado_civil = "Soltero" || estado_civil = "Casado" || 
estado_civil = "Divorciado" || estado_civil = "Viudo"
|| estado_civil = "Juntado"));

create table Campo(
id_campo integer not null,
nombre varchar(30) not null,
ubicacion varchar(30) not null,
cantidad_bateas integer not null,
dni Integer not null,
constraint pk_campo primary key (id_campo),
constraint restriccion_bateas check (cantidad_bateas >= 0),
constraint restriccion_dni check (dni > 0),
constraint fk_duenho foreign key (dni) references Duenho(dni) on update cascade on delete cascade
);
	
create table Invertir(
id_campo Integer not null,
dni Integer not null,
constraint fk_campo Foreign key (id_campo) references Campo (id_campo) on update cascade on delete cascade, 
constraint fk_inversor Foreign key (dni) references Inversor (dni) on update cascade on delete cascade,
constraint restriccion_dni check(dni > 0),
constraint restriccion_id_campo check(id_campo >= 0),
constraint pk_invertir primary key(id_campo,dni));    
    
create table Campanha(
anho Integer not null,
precio_bulbo Float not null,
precio_pistillo Float not null,
constraint pk_Campanha primary key(anho),
constraint restriccion_anho check (anho >= 2020),
constraint restricciondos_anho check (anho < 2100));

create table Realiza(anho Integer not null,
id_campo Integer not null,
dni Integer not null,
dinero float not null,
cantidad_bulbos_generados Integer not null,
cantidad_pistillos Integer not null,
batea Integer not null,
constraint pk_realiza primary key (anho, id_campo, dni),
constraint restriccion_anho check(anho >= 2020),
constraint restriccion_dni check(dni > 0),
constraint restriccion_id_campo check(id_campo >= 0),
constraint fk_campo_realiza foreign key (id_campo) references Campo(id_campo) on update cascade on delete cascade,
constraint fk_inversor_realiza foreign key (dni) references Inversor(dni) on update cascade on delete cascade,
constraint fk_campanha_realiza foreign key (anho) references Campanha(anho) on update cascade on delete cascade);

create table AuditoriaBatea (
id_campo Integer not null primary key,
fecha_del_cambio Date not null,
cantidad_anterior Integer not null,
cantidad_nueva Integer not null,
usuario varchar(50) not null,
constraint fk_auditoria_campo foreign key (id_campo) references Campo(id_campo),
constraint restriccion_dni check(dni > 0),
constraint restriccion_id_campo check(id_campo >= 0));

DELIMITER $$
create trigger auditoria_de_batea 
after update on Campo for each row 
begin	
	if(OLD.cantidad_bateas <> NEW.cantidad_bateas) then
	insert into AuditoriaBatea values(OLD.id_campo, NOW(), OLD.cantidad_bateas, NEW.cantidad_bateas, CURRENT_USER());
    end if;
end;
$$ 
DELIMITER ;
